import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const SOURCE = await readFile(new URL('../content/main-world.js', import.meta.url), 'utf8');

function createSandbox(nativeFetch, storedValue = null) {
  const documentStub = {
    head: null,
    documentElement: {
      appendChild: () => {}
    },
    createElement: () => ({}),
    addEventListener: () => {},
    querySelectorAll: () => []
  };
  documentStub.head = documentStub.documentElement;

  const storage = new Map();
  if (storedValue !== null) {
    storage.set('rutube-no-ads:enabled', storedValue);
  }
  const windowListeners = [];

  const sandbox = {
    console,
    URL,
    Response,
    Headers,
    Event,
    setTimeout: () => 0,
    clearTimeout: () => {},
    setInterval: () => 0,
    clearInterval: () => {},
    postMessage: () => {},
    localStorage: {
      getItem: (key) => (storage.has(key) ? storage.get(key) : null),
      setItem: (key, value) => storage.set(key, String(value))
    },
    document: documentStub,
    fetch: nativeFetch
  };
  sandbox.window = sandbox;
  sandbox.addEventListener = (type, handler) => {
    windowListeners.push({ type, handler });
  };
  sandbox.readStored = () => storage.get('rutube-no-ads:enabled') || null;

  vm.createContext(sandbox);
  const contextWindow = vm.runInContext('window', sandbox);
  sandbox.dispatchMessage = (data) => {
    for (const listener of windowListeners) {
      if (listener.type === 'message') {
        listener.handler({ source: contextWindow, data });
      }
    }
  };
  vm.runInContext(SOURCE, sandbox, { filename: 'main-world.js' });
  return sandbox;
}

function apiSandbox(payload) {
  return createSandbox(async () =>
    new Response(JSON.stringify(payload), {
      status: 200,
      headers: { 'content-type': 'application/json; charset=utf-8' }
    })
  );
}

test('скрипт экспортирует отладочный API', () => {
  const sandbox = createSandbox(async () => new Response('{}'));
  const debug = sandbox.__rutubeNoAdsDebug;
  assert.equal(typeof debug, 'object');
  assert.equal(debug.version, '2.0.0');
  assert.equal(debug.lastError, undefined);
});

test('isAdUrl распознаёт рекламные хосты и пути', () => {
  const { isAdUrl } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;

  assert.equal(isAdUrl('https://a.rutube.ru/vast/rolls?partner=1'), true);
  assert.equal(isAdUrl('https://cdn.a.rutube.ru/creative.mp4'), true);
  assert.equal(isAdUrl('https://an.yandex.ru/count/12345'), true);
  assert.equal(isAdUrl('/api/adv/v1/roll'), true);

  assert.equal(isAdUrl('https://rutube.ru/api/play/options/abc/'), false);
  assert.equal(isAdUrl('https://bl.rutube.ru/video/abc/index.m3u8'), false);
  assert.equal(isAdUrl(''), false);
  assert.equal(isAdUrl(undefined), false);
});

test('isRutubeApiUrl отличает API RUTUBE от сторонних адресов', () => {
  const { isRutubeApiUrl } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;

  assert.equal(isRutubeApiUrl('https://rutube.ru/api/video/12345/'), true);
  assert.equal(isRutubeApiUrl('/api/play/options/12345/'), true);
  assert.equal(isRutubeApiUrl('https://example.org/api/video/'), false);
  assert.equal(isRutubeApiUrl('https://rutube.ru/video/12345/'), false);
});

test('hasAdToken не срабатывает на похожие слова', () => {
  const { hasAdToken } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;

  assert.equal(hasAdToken('ra-ad-container'), true);
  assert.equal(hasAdToken('advertising-overlay'), true);
  assert.equal(hasAdToken('video-ad-slot'), true);

  assert.equal(hasAdToken('loading'), false);
  assert.equal(hasAdToken('shadow'), false);
  assert.equal(hasAdToken('thread-container'), false);
  assert.equal(hasAdToken(''), false);
});

test('stripAdPayload вычищает рекламные ключи и сохраняет контент', () => {
  const { stripAdPayload } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;

  const payload = {
    title: 'Урок физики',
    video: {
      url: 'https://bl.rutube.ru/video/1.m3u8',
      advertising: { preroll: ['https://a.rutube.ru/roll1'] },
      ad_rolls: [{ url: 'https://a.rutube.ru/roll2' }],
      vast_url: 'https://a.rutube.ru/vast',
      midrolls: [{ time: 60 }]
    },
    banners: ['https://an.yandex.ru/banner'],
    adEnabled: true
  };

  assert.equal(stripAdPayload(payload), true);
  assert.equal(payload.title, 'Урок физики');
  assert.equal(payload.video.url, 'https://bl.rutube.ru/video/1.m3u8');
  assert.equal(JSON.stringify(payload.video.advertising), '{}');
  assert.equal(JSON.stringify(payload.video.ad_rolls), '[]');
  assert.equal(payload.video.vast_url, '');
  assert.equal(JSON.stringify(payload.video.midrolls), '[]');
  assert.equal(JSON.stringify(payload.banners), '[]');
  assert.equal(payload.adEnabled, false);
});

test('stripAdPayload не трогает данные без рекламы', () => {
  const { stripAdPayload } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;
  const payload = { title: 'Урок', duration: 240, chapters: [{ start: 0, name: 'Вступление' }] };

  assert.equal(stripAdPayload(payload), false);
  assert.deepEqual(payload, { title: 'Урок', duration: 240, chapters: [{ start: 0, name: 'Вступление' }] });
  assert.equal(stripAdPayload(null), false);
  assert.equal(stripAdPayload('строка'), false);
});

test('stripAdPayload не путает рекламные флаги с обычными словами', () => {
  const { stripAdPayload } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;
  const payload = {
    address: 'Москва',
    admin: { name: 'Модератор' },
    adaptive: true,
    adEnabled: true
  };

  assert.equal(stripAdPayload(payload), true);
  assert.equal(payload.address, 'Москва');
  assert.equal(payload.admin.name, 'Модератор');
  assert.equal(payload.adaptive, true);
  assert.equal(payload.adEnabled, false);
});

test('patched fetch отдаёт пустой JSON вместо рекламного запроса', async () => {
  let nativeCalls = 0;
  const sandbox = createSandbox(async () => {
    nativeCalls += 1;
    return new Response('{"should":"not be used"}', { headers: { 'content-type': 'application/json' } });
  });

  const response = await sandbox.fetch('https://a.rutube.ru/vast/roll');
  assert.equal(response.status, 200);
  assert.equal(await response.text(), '{}');
  assert.equal(nativeCalls, 0);
});

test('patched fetch вычищает рекламу из ответа API RUTUBE', async () => {
  const sandbox = apiSandbox({
    result: {
      title: 'Урок',
      advertising: { preroll: ['roll1'] },
      video_url: 'https://bl.rutube.ru/video/1.m3u8'
    }
  });

  const response = await sandbox.fetch('https://rutube.ru/api/play/options/abc/');
  const data = await response.json();

  assert.equal(data.result.title, 'Урок');
  assert.equal(data.result.video_url, 'https://bl.rutube.ru/video/1.m3u8');
  assert.deepEqual(data.result.advertising, {});
});

test('patched fetch не пересобирает ответ без рекламных полей', async () => {
  const sandbox = apiSandbox({ result: { title: 'Урок', duration: 240 } });

  const response = await sandbox.fetch('https://rutube.ru/api/video/1/');
  assert.equal(response.status, 200);
  assert.equal((await response.json()).result.duration, 240);
});

test('patched fetch не трогает ответы сторонних API', async () => {
  const sandbox = apiSandbox({ advertising: { preroll: ['roll1'] } });

  const response = await sandbox.fetch('https://example.org/api/video/');
  const data = await response.json();

  assert.equal(JSON.stringify(data.advertising), '{"preroll":["roll1"]}');
});

test('normalizeEnabled понимает сохранённое значение', () => {
  const { normalizeEnabled } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;

  assert.equal(normalizeEnabled('1'), true);
  assert.equal(normalizeEnabled(null), true);
  assert.equal(normalizeEnabled('0'), false);
  assert.equal(normalizeEnabled(0), false);
  assert.equal(normalizeEnabled(false), false);
});

test('formatToggleLabel описывает состояние кнопки', () => {
  const { formatToggleLabel } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;

  assert.equal(formatToggleLabel(true), 'Реклама выключена');
  assert.equal(formatToggleLabel(false), 'Реклама включена');
});

test('при выключенной блокировке запросы к рекламным хостам проходят', async () => {
  let nativeCalls = 0;
  const sandbox = createSandbox(async () => {
    nativeCalls += 1;
    return new Response('{"advertising":{"preroll":["roll1"]}}', {
      status: 200,
      headers: { 'content-type': 'application/json' }
    });
  }, '0');

  const response = await sandbox.fetch('https://a.rutube.ru/vast/roll');
  assert.equal(nativeCalls, 1);
  assert.equal(response.status, 200);
  assert.equal(JSON.stringify(await response.json()), '{"advertising":{"preroll":["roll1"]}}');
});

test('сообщение с панели браузера выключает блокировку', async () => {
  let nativeCalls = 0;
  const sandbox = createSandbox(async () => {
    nativeCalls += 1;
    return new Response('{}', { status: 200 });
  });

  sandbox.dispatchMessage({ source: 'rutube-no-ads', type: 'state', enabled: false });

  assert.equal(sandbox.readStored(), '0');
  await sandbox.fetch('https://a.rutube.ru/vast/roll');
  assert.equal(nativeCalls, 1);
});

test('сообщения из других источников и с неверным типом игнорируются', async () => {
  let nativeCalls = 0;
  const sandbox = createSandbox(async () => {
    nativeCalls += 1;
    return new Response('{}', { status: 200 });
  });

  sandbox.dispatchMessage({ source: 'someone-else', type: 'state', enabled: false });
  sandbox.dispatchMessage({ source: 'rutube-no-ads', type: 'other', enabled: false });
  sandbox.dispatchMessage({ source: 'rutube-no-ads', type: 'state', enabled: 'нет' });

  assert.equal(sandbox.readStored(), null);
  await sandbox.fetch('https://a.rutube.ru/vast/roll');
  assert.equal(nativeCalls, 0);
});

test('matchesAdblockNotice узнаёт уведомление RUTUBE о блокировщике', () => {
  const { matchesAdblockNotice } = createSandbox(async () => new Response('{}')).__rutubeNoAdsDebug;

  const notice = 'Блокировщик рекламы может помешать правильной работе плеера. Отключите его в расширениях браузера';
  assert.equal(matchesAdblockNotice(notice), true);
  assert.equal(matchesAdblockNotice('  Блокировщик\n  рекламы  может помешать  '), true);

  assert.equal(matchesAdblockNotice('Обычный текст страницы без предупреждений'), false);
  assert.equal(matchesAdblockNotice(`${'Блокировщик рекламы '.repeat(30)}`), false);
  assert.equal(matchesAdblockNotice(''), false);
  assert.equal(matchesAdblockNotice(null), false);
});
