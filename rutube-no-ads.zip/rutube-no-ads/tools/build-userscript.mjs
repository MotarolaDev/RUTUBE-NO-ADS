import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(await readFile(join(root, 'manifest.json'), 'utf8'));
const core = await readFile(join(root, 'content', 'main-world.js'), 'utf8');

const header = `// ==UserScript==
// @name         RUTUBE без рекламы
// @namespace    rutube-no-ads
// @version      ${manifest.version}
// @description  Убирает рекламу на RUTUBE: рекламные запросы, баннеры, авто-пропуск вставок и кнопка включения/отключения
// @author       MultiTool
// @match        *://rutube.ru/*
// @match        *://*.rutube.ru/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

`;

await mkdir(join(root, 'firefox'), { recursive: true });
const target = join(root, 'firefox', 'rutube-no-ads.user.js');
await writeFile(target, header + core, 'utf8');

console.log(`собрано: ${target}`);
