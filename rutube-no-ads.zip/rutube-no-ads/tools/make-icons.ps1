﻿Add-Type -AssemblyName System.Drawing

$outDir = Join-Path (Split-Path $PSScriptRoot -Parent) 'icons'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$canvas = 512
$bitmap = New-Object System.Drawing.Bitmap($canvas, $canvas, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$graphics.Clear([System.Drawing.Color]::Transparent)

$inset = 18.0
$radius = 112.0
$rect = New-Object System.Drawing.RectangleF($inset, $inset, ($canvas - 2 * $inset), ($canvas - 2 * $inset))
$diameter = $radius * 2

$shape = New-Object System.Drawing.Drawing2D.GraphicsPath
$shape.AddArc($rect.X, $rect.Y, $diameter, $diameter, 180, 90)
$shape.AddArc(($rect.Right - $diameter), $rect.Y, $diameter, $diameter, 270, 90)
$shape.AddArc(($rect.Right - $diameter), ($rect.Bottom - $diameter), $diameter, $diameter, 0, 90)
$shape.AddArc($rect.X, ($rect.Bottom - $diameter), $diameter, $diameter, 90, 90)
$shape.CloseFigure()

$background = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
    $rect,
    [System.Drawing.Color]::FromArgb(255, 30, 34, 42),
    [System.Drawing.Color]::FromArgb(255, 14, 16, 20),
    90.0
)
$graphics.FillPath($background, $shape)

$font = New-Object System.Drawing.Font('Segoe UI', 268, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$format = New-Object System.Drawing.StringFormat
$format.Alignment = [System.Drawing.StringAlignment]::Center
$format.LineAlignment = [System.Drawing.StringAlignment]::Center
$white = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 245, 247, 250))
$graphics.DrawString('R', $font, $white, $rect, $format)

$outlinePen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(255, 14, 16, 20), 62)
$outlinePen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
$outlinePen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
$graphics.DrawLine($outlinePen, 146, 366, 366, 146)

$accentPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(255, 53, 208, 127), 40)
$accentPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
$accentPen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
$graphics.DrawLine($accentPen, 146, 366, 366, 146)

$accentPen.Dispose()
$outlinePen.Dispose()
$white.Dispose()
$font.Dispose()
$background.Dispose()
$shape.Dispose()
$graphics.Dispose()

foreach ($size in @(16, 32, 48, 128)) {
    $small = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $smallGraphics = [System.Drawing.Graphics]::FromImage($small)
    $smallGraphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $smallGraphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $smallGraphics.Clear([System.Drawing.Color]::Transparent)
    $smallGraphics.DrawImage($bitmap, 0, 0, $size, $size)
    $smallGraphics.Dispose()
    $target = Join-Path $outDir ("icon{0}.png" -f $size)
    $small.Save($target, [System.Drawing.Imaging.ImageFormat]::Png)
    $small.Dispose()
    Write-Host ("{0} -> {1} bytes" -f $target, (Get-Item -LiteralPath $target).Length)
}

$bitmap.Dispose()
