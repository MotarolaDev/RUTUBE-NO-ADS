﻿Add-Type -AssemblyName System.Windows.Forms | Out-Null

$root = Split-Path $PSScriptRoot -Parent
$extensionsUrl = 'chrome://extensions'
$browserName = 'Chromium-браузер'
$isFirefox = $false
$isChromium = $true

$userChoice = 'HKCU:\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice'
$progId = ''
try {
    $progId = (Get-ItemProperty -LiteralPath $userChoice -ErrorAction Stop).ProgId
}
catch {
    $progId = ''
}

if ($progId -match 'Firefox') {
    $isFirefox = $true
    $isChromium = $false
    $browserName = 'Mozilla Firefox'
}
elseif ($progId -match 'Yandex') {
    $extensionsUrl = 'browser://extensions'
    $browserName = 'Яндекс Браузер'
}
elseif ($progId -match 'Edge') {
    $extensionsUrl = 'edge://extensions'
    $browserName = 'Microsoft Edge'
}
elseif ($progId -match 'Opera') {
    $extensionsUrl = 'opera://extensions'
    $browserName = 'Opera'
}
elseif ($progId -match 'Vivaldi') {
    $extensionsUrl = 'vivaldi://extensions'
    $browserName = 'Vivaldi'
}
elseif ($progId -match 'Brave') {
    $extensionsUrl = 'brave://extensions'
    $browserName = 'Brave'
}
elseif ($progId -match 'Chrome') {
    $extensionsUrl = 'chrome://extensions'
    $browserName = 'Google Chrome'
}

function Copy-ToClipboard {
    param([string]$Text)
    try {
        Set-Clipboard -Value $Text -ErrorAction Stop
        return $true
    }
    catch {
        return $false
    }
}

if ($isFirefox) {
    $amoUrl = 'https://addons.mozilla.org/ru/firefox/addon/tampermonkey/'
    $copied = Copy-ToClipboard -Text $amoUrl
    if ($copied) {
        $clipboardNote = 'Ссылка уже скопирована — нажмите Ctrl+V в адресной строке.'
    }
    else {
        $clipboardNote = "Ссылка: $amoUrl"
    }

    $message = @"
Установка для Firefox (делается ОДИН раз).

Ваш браузер: $browserName
$clipboardNote

1. Откройте ссылку и нажмите «Добавить в Firefox» → «Добавить»
   (это Tampermonkey — менеджер пользовательских скриптов).
2. Откройте Tampermonkey → «Панель управления» → вкладка «Утилиты»
   → «Импорт из файла».
3. Выберите файл  rutube-no-ads\firefox\rutube-no-ads.user.js
   из открытой папки.
   Если импорт не сработал: «Создать новый скрипт», удалите шаблон,
   вставьте туда содержимое этого файла и нажмите Ctrl+S.
4. Откройте rutube.ru — внизу справа появится кнопка «Реклама выключена».

Честно о Firefox: в видео реклама не запрашивается заранее, а пропускается
автоматически — звук глушится, вставка перематывается, баннеры и рекламные
запросы убираются. Полностью запретить сам запрос видео-рекламы Firefox
пользовательским скриптам не даёт. В Chrome, Edge и Яндекс Браузере работает
папка с расширением из этой же папки — оно блокирует запросы целиком.
"@

    [System.Windows.Forms.MessageBox]::Show($message, 'RUTUBE без рекламы', 'OK', 'Information') | Out-Null
    exit 0
}

if (-not $isChromium) {
    $unsupported = @"
Ваш браузер: $browserName

Ничего не выбрано. Откройте этот файл в браузере на Chromium
(Яндекс Браузер, Google Chrome, Microsoft Edge, Opera, Vivaldi, Brave)
или в Firefox.
"@
    [System.Windows.Forms.MessageBox]::Show($unsupported, 'RUTUBE без рекламы', 'OK', 'Warning') | Out-Null
    exit 0
}

$clipboardNote = 'Адрес уже скопирован в буфер обмена — нажмите Ctrl+V в адресной строке.'
$copied = Copy-ToClipboard -Text $extensionsUrl
if (-not $copied) {
    $clipboardNote = "Адрес страницы: $extensionsUrl"
}

$message = @"
Установка расширения с кнопкой (делается ОДИН раз, шагов три).

Ваш браузер: $browserName
Страница расширений: $extensionsUrl
$clipboardNote

1. Откройте эту страницу в браузере.
2. Включите «Режим разработчика» (Developer mode) в правом верхнем углу.
3. Нажмите «Загрузить распакованное расширение» (Load unpacked)
   и выберите открытую папку rutube-no-ads (ту, где лежит manifest.json).

Готово. Значок расширения появится на панели браузера рядом с адресной строкой,
а на страницах RUTUBE — кнопка «Реклама выключена».
Настройка сохраняется после перезагрузки страницы, браузера и компьютера,
этот файл больше запускать не нужно.
"@

[System.Windows.Forms.MessageBox]::Show($message, 'RUTUBE без рекламы', 'OK', 'Information') | Out-Null
