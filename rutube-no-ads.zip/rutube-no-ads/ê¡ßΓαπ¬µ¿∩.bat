@echo off
setlocal
explorer "%~dp0."
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\show-install-hint.ps1"
exit /b
