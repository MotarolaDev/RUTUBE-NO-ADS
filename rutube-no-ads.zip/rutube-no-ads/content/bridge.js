'use strict';

(() => {
  const SOURCE = 'rutube-no-ads';
  const MESSAGE_SET_ENABLED = 'rutube-no-ads:set-enabled';
  const MESSAGE_STATE = 'rutube-no-ads:state';

  function postState(enabled) {
    window.postMessage({ source: SOURCE, type: 'state', enabled: Boolean(enabled) }, '*');
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (!data || data.source !== SOURCE || data.type !== 'state') {
      return;
    }
    try {
      const result = chrome.runtime.sendMessage({
        type: MESSAGE_SET_ENABLED,
        blocked: Boolean(data.enabled)
      });
      if (result && typeof result.catch === 'function') {
        result.catch(() => {});
      }
    } catch (error) {
      // расширение перезагружено — состояние применится при следующем открытии страницы
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== MESSAGE_STATE) {
      return false;
    }
    postState(message.blocked);
    sendResponse({ ok: true });
    return false;
  });
})();
