'use strict';

const STORAGE_KEY = 'adsBlocked';
const RULESET_ID = 'ads';
const MESSAGE_SET_ENABLED = 'rutube-no-ads:set-enabled';
const MESSAGE_STATE = 'rutube-no-ads:state';
const BADGE_COLOR = '#ff6b6b';

async function readBlocked() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return stored[STORAGE_KEY] !== false;
}

async function applyBlocked(blocked) {
  await chrome.storage.local.set({ [STORAGE_KEY]: blocked });
  await chrome.declarativeNetRequest.updateEnabledRulesets(
    blocked
      ? { enableRulesetIds: [RULESET_ID] }
      : { disableRulesetIds: [RULESET_ID] }
  );
  await chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR });
  await chrome.action.setBadgeText({ text: blocked ? '' : 'OFF' });
}

async function syncFromStorage() {
  const blocked = await readBlocked();
  await applyBlocked(blocked);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== MESSAGE_SET_ENABLED) {
    return false;
  }
  applyBlocked(Boolean(message.blocked))
    .then(() => sendResponse({ ok: true, blocked: Boolean(message.blocked) }))
    .catch((error) => sendResponse({ ok: false, error: String(error) }));
  return true;
});

chrome.action.onClicked.addListener((tab) => {
  readBlocked()
    .then(async (current) => {
      const next = !current;
      await applyBlocked(next);
      if (tab && typeof tab.id === 'number') {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: MESSAGE_STATE, blocked: next });
        } catch (error) {
          // на этой вкладке нет страницы RUTUBE — настройка применится при следующем открытии
        }
      }
    })
    .catch(() => {});
});

chrome.runtime.onInstalled.addListener(() => {
  syncFromStorage().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  syncFromStorage().catch(() => {});
});
