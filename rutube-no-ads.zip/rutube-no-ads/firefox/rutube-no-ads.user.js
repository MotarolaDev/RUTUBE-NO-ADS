// ==UserScript==
// @name         RUTUBE без рекламы
// @namespace    rutube-no-ads
// @version      2.0.0
// @description  Убирает рекламу на RUTUBE: рекламные запросы, баннеры, авто-пропуск вставок и кнопка включения/отключения
// @author       MultiTool
// @match        *://rutube.ru/*
// @match        *://*.rutube.ru/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  'use strict';

  const VERSION = '2.0.0';
  const TICK_INTERVAL_MS = 300;
  const MAX_PLAYBACK_RATE = 16;
  const SEEK_GUARD_SECONDS = 0.5;
  const MAX_WALK_DEPTH = 8;
  const MIN_VIDEO_SIDE_PX = 40;
  const STORAGE_KEY = 'rutube-no-ads:enabled';
  const MESSAGE_SOURCE = 'rutube-no-ads';
  const TOGGLE_HOST_ID = 'rutube-no-ads-toggle';

  const AD_HOSTS = [
    'a.rutube.ru',
    'goya.rutube.ru',
    'an.yandex.ru',
    'yabs.yandex.ru',
    'ads.adfox.ru',
    'adfox.ru',
    'ad.mail.ru',
    'top-fwz1.mail.ru',
    'target.my.com',
    'tns-counter.ru',
    'counter.yadro.ru'
  ];

  const AD_URL_MARKERS = ['/api/adv/', '/api/advertising/', 'adfox', '/vast', '/vmap'];

  const AD_KEY_RE = /^(ad|ads|adv|advert|advertising|advertisement|ad_roll|ad_rolls|ad_config|ad_banner|ad_banners|adfox|advertising_config|banner|banners|external_advertising|midroll|midrolls|postroll|postrolls|preroll|prerolls|pauseroll|pauserolls|roll_config|rolls_config|vast|vast_url|vmap|vmap_url|yandex_ad)$/;

  const CAMEL_AD_KEY_RE = /^ad[_A-Z]/;

  const AD_TOKENS = new Set([
    'ad',
    'ads',
    'adv',
    'advert',
    'advertising',
    'advertisement',
    'adfox',
    'preroll',
    'midroll',
    'postroll',
    'pauseroll',
    'banner',
    'banners',
    'vast',
    'vmap'
  ]);

  const AD_UI_SELECTOR = [
    '[class*="advert" i]',
    '[class*="ra-ad" i]',
    '[class*="ad-overlay" i]',
    '[class*="ad-container" i]',
    '[class*="video-ad" i]',
    '[class*="preroll" i]',
    '[class*="midroll" i]',
    '[data-testid*="advert" i]',
    '[id*="adfox" i]'
  ].join(',');

  const AD_UI_CSS = [
    '[class*="advert" i]:not(:has(video)),',
    '[class*="ra-ad" i]:not(:has(video)),',
    '[class*="adfox" i]:not(:has(video)),',
    '[class*="advertising" i]:not(:has(video)),',
    '[class*="ad-banner" i]:not(:has(video)),',
    '[data-testid*="advert" i]:not(:has(video)),',
    '[id*="adfox" i]:not(:has(video)),',
    '[id^="yandex_rtb" i]:not(:has(video)),',
    'iframe[src*="an.yandex.ru" i],',
    'iframe[src*="adfox" i] {',
    '  display: none !important;',
    '}'
  ].join('\n');

  const TOGGLE_CSS = [
    ':host { all: initial; }',
    '.toggle {',
    '  position: fixed;',
    '  right: 16px;',
    '  bottom: 16px;',
    '  z-index: 2147483647;',
    '  display: inline-flex;',
    '  align-items: center;',
    '  gap: 8px;',
    '  margin: 0;',
    '  padding: 8px 14px;',
    '  border: 1px solid rgba(255, 255, 255, 0.18);',
    '  border-radius: 999px;',
    '  background: #16181d;',
    '  color: #f5f7fa;',
    '  font: 500 13px/1.2 -apple-system, "Segoe UI", Roboto, Arial, sans-serif;',
    '  letter-spacing: 0.1px;',
    '  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.28);',
    '  cursor: pointer;',
    '  transition: background-color 160ms ease, border-color 160ms ease;',
    '}',
    '.toggle:hover { background: #22262e; }',
    '.toggle:active { background: #101216; }',
    '.toggle:focus-visible { outline: 2px solid #7cc4ff; outline-offset: 2px; }',
    '.dot {',
    '  width: 8px;',
    '  height: 8px;',
    '  border-radius: 50%;',
    '  background: #35d07f;',
    '  box-shadow: 0 0 0 3px rgba(53, 208, 127, 0.18);',
    '}',
    '.toggle.off .dot {',
    '  background: #ff6b6b;',
    '  box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.18);',
    '}',
    '.label { white-space: nowrap; }',
    '@media (prefers-reduced-motion: reduce) { .toggle { transition: none; } }'
  ].join('\n');

  const SKIP_LABEL_RE = /пропустить|пропуск рекламы|skip\s*ad/i;
  const NOTICE_TEXT_RE = /блокировщик рекламы/i;
  const NOTICE_TEXT_MAX_LENGTH = 400;
  const NOTICE_PARENT_DEPTH = 4;

  let blockingEnabled = true;
  let hijack = null;
  let styleElement = null;
  let toggleHost = null;
  let toggleParts = null;
  let noticeObserver = null;

  function parseUrl(url) {
    try {
      return new URL(String(url), 'https://rutube.ru/');
    } catch (error) {
      return null;
    }
  }

  function isRutubeHost(hostname) {
    return hostname === 'rutube.ru' || hostname.endsWith('.rutube.ru');
  }

  function isAdUrl(url) {
    if (typeof url !== 'string' || url === '') {
      return false;
    }
    const parsed = parseUrl(url);
    if (!parsed) {
      return false;
    }
    const host = parsed.hostname.toLowerCase();
    if (AD_HOSTS.some((adHost) => host === adHost || host.endsWith('.' + adHost))) {
      return true;
    }
    const target = (parsed.pathname + parsed.search).toLowerCase();
    return AD_URL_MARKERS.some((marker) => target.includes(marker));
  }

  function isRutubeApiUrl(url) {
    const parsed = parseUrl(url);
    if (!parsed) {
      return false;
    }
    return isRutubeHost(parsed.hostname.toLowerCase()) && parsed.pathname.toLowerCase().startsWith('/api/');
  }

  function isAdKey(key) {
    const text = String(key);
    const lower = text.toLowerCase();
    if (AD_KEY_RE.test(lower) || lower.startsWith('ad_') || lower.includes('advert')) {
      return true;
    }
    // camelCase-флаги вида adEnabled/adRolls ловим только по заглавной букве,
    // иначе под фильтр попадут address, admin и adaptive
    return CAMEL_AD_KEY_RE.test(text);
  }

  function neutralize(value) {
    if (Array.isArray(value)) {
      return [];
    }
    if (value === null) {
      return null;
    }
    if (typeof value === 'object') {
      return {};
    }
    if (typeof value === 'boolean') {
      return false;
    }
    if (typeof value === 'number') {
      return 0;
    }
    if (typeof value === 'string') {
      return '';
    }
    return null;
  }

  function stripAdPayload(payload) {
    if (!payload || typeof payload !== 'object') {
      return false;
    }
    const seen = new WeakSet();
    let changed = false;

    const walk = (node, depth) => {
      if (!node || typeof node !== 'object' || depth > MAX_WALK_DEPTH) {
        return;
      }
      if (seen.has(node)) {
        return;
      }
      seen.add(node);
      for (const key of Object.keys(node)) {
        const value = node[key];
        if (isAdKey(key)) {
          node[key] = neutralize(value);
          changed = true;
          continue;
        }
        if (value && typeof value === 'object') {
          walk(value, depth + 1);
        }
      }
    };

    walk(payload, 0);
    return changed;
  }

  function hasAdToken(value) {
    if (typeof value !== 'string' || value === '') {
      return false;
    }
    const tokens = value.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
    return tokens.some((token) => AD_TOKENS.has(token));
  }

  function normalizeEnabled(value) {
    return !(value === '0' || value === 0 || value === false);
  }

  function formatToggleLabel(enabled) {
    return enabled ? 'Реклама выключена' : 'Реклама включена';
  }

  function matchesAdblockNotice(text) {
    if (typeof text !== 'string') {
      return false;
    }
    const value = text.replace(/\s+/g, ' ').trim();
    if (value.length === 0 || value.length > NOTICE_TEXT_MAX_LENGTH) {
      return false;
    }
    return NOTICE_TEXT_RE.test(value);
  }

  function hideAdblockNotice(node) {
    if (!blockingEnabled || !node || node.nodeType !== 1) {
      return false;
    }
    if (!matchesAdblockNotice(node.textContent || '')) {
      return false;
    }
    let target = node;
    let depth = 0;
    while (target.parentElement && depth < NOTICE_PARENT_DEPTH) {
      if (!matchesAdblockNotice(target.parentElement.textContent || '')) {
        break;
      }
      target = target.parentElement;
      depth += 1;
    }
    target.style.setProperty('display', 'none', 'important');
    return true;
  }

  function watchAdblockNotice() {
    if (noticeObserver || typeof MutationObserver !== 'function' || !document.body) {
      return;
    }
    noticeObserver = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (hideAdblockNotice(node)) {
            return;
          }
        }
      }
    });
    noticeObserver.observe(document.body, { childList: true, subtree: true });
  }

  function readStoredState() {
    try {
      return normalizeEnabled(window.localStorage.getItem(STORAGE_KEY));
    } catch (error) {
      return true;
    }
  }

  function persistState(enabled) {
    try {
      window.localStorage.setItem(STORAGE_KEY, enabled ? '1' : '0');
    } catch (error) {
      // приватный режим или запрет localStorage — настройка проживёт до перезагрузки страницы
    }
  }

  function isVisible(element) {
    if (!element || element.nodeType !== 1) {
      return false;
    }
    const rect = element.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) {
      return false;
    }
    const view = element.ownerDocument.defaultView;
    if (!view) {
      return true;
    }
    const style = view.getComputedStyle(element);
    return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
  }

  function intersects(a, b) {
    return a.right > b.left && a.left < b.right && a.bottom > b.top && a.top < b.bottom;
  }

  function isAdMediaSource(video) {
    const source = video.currentSrc || video.src || '';
    if (source && isAdUrl(source)) {
      return true;
    }
    for (const node of video.querySelectorAll('source')) {
      if (node.src && isAdUrl(node.src)) {
        return true;
      }
    }
    return false;
  }

  function hasAdMarkup(video) {
    return hasAdToken(typeof video.className === 'string' ? video.className : '');
  }

  function adUiOverVideo(video) {
    const videoRect = video.getBoundingClientRect();
    if (videoRect.width < MIN_VIDEO_SIDE_PX || videoRect.height < MIN_VIDEO_SIDE_PX) {
      return null;
    }
    for (const node of document.querySelectorAll(AD_UI_SELECTOR)) {
      if (node.contains(video)) {
        continue;
      }
      const classValue = typeof node.className === 'string' ? node.className : '';
      const testId = node.getAttribute('data-testid') || '';
      if (!hasAdToken(classValue) && !hasAdToken(node.id || '') && !hasAdToken(testId)) {
        continue;
      }
      if (!isVisible(node)) {
        continue;
      }
      if (intersects(node.getBoundingClientRect(), videoRect)) {
        return node;
      }
    }
    return null;
  }

  function isAdState(video) {
    return isAdMediaSource(video) || hasAdMarkup(video) || adUiOverVideo(video) !== null;
  }

  function clickSkipButton() {
    for (const button of document.querySelectorAll('button, [role="button"]')) {
      const label = `${button.textContent || ''} ${button.getAttribute('aria-label') || ''}`;
      if (!SKIP_LABEL_RE.test(label)) {
        continue;
      }
      if (!isVisible(button) || button.disabled) {
        continue;
      }
      button.click();
      return true;
    }
    return false;
  }

  function engage(video) {
    if (!hijack || hijack.video !== video) {
      hijack = {
        video,
        rate: video.playbackRate,
        muted: video.muted
      };
    }
    video.muted = true;
    if (video.playbackRate !== MAX_PLAYBACK_RATE) {
      try {
        video.playbackRate = MAX_PLAYBACK_RATE;
      } catch (error) {
        // некоторые плееры блокируют смену скорости — тогда остаётся только mute и перемотка
      }
    }
    const duration = video.duration;
    if (Number.isFinite(duration) && duration > 0 && video.seekable.length > 0) {
      const target = Math.max(0, duration - SEEK_GUARD_SECONDS);
      if (video.currentTime < target) {
        try {
          video.currentTime = target;
        } catch (error) {
          // живые потоки и MSE не всегда дают перемотать — пропускаем этот шаг
        }
      }
    }
    clickSkipButton();
  }

  function release() {
    if (!hijack) {
      return;
    }
    const video = hijack.video;
    const rate = hijack.rate;
    const muted = hijack.muted;
    hijack = null;
    try {
      video.playbackRate = rate;
    } catch (error) {
      // элемент мог быть уже удалён со страницы
    }
    video.muted = muted;
  }

  function tick() {
    if (!blockingEnabled) {
      return;
    }
    if (toggleHost && !toggleHost.isConnected) {
      toggleHost = null;
      toggleParts = null;
      mountToggle();
    }
    const videos = document.querySelectorAll('video');
    if (videos.length === 0) {
      release();
      return;
    }
    for (const video of videos) {
      if (isAdState(video)) {
        engage(video);
        return;
      }
    }
    release();
  }

  function createEmptyResponse() {
    return new Response('{}', {
      status: 200,
      statusText: 'OK',
      headers: { 'Content-Type': 'application/json' }
    });
  }

  async function cleanJsonResponse(response, url) {
    if (!blockingEnabled || !response || !response.ok || !isRutubeApiUrl(url)) {
      return response;
    }
    try {
      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('json')) {
        return response;
      }
      const data = await response.clone().json();
      if (!stripAdPayload(data)) {
        return response;
      }
      const headers = new Headers();
      headers.set('content-type', contentType);
      return new Response(JSON.stringify(data), {
        status: response.status,
        statusText: response.statusText,
        headers
      });
    } catch (error) {
      return response;
    }
  }

  function patchFetch(win) {
    const nativeFetch = win.fetch;
    if (typeof nativeFetch !== 'function') {
      return;
    }
    win.fetch = function patchedFetch(input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      if (blockingEnabled && isAdUrl(url)) {
        return Promise.resolve(createEmptyResponse());
      }
      return nativeFetch.call(this, input, init).then((response) => cleanJsonResponse(response, url));
    };
  }

  function fakeXhrResponse(xhr, url) {
    const isJson = xhr.responseType === 'json';
    const body = isJson ? {} : '{}';
    const define = (name, value) => {
      try {
        Object.defineProperty(xhr, name, { configurable: true, get: () => value });
      } catch (error) {
        // часть свойств XHR переопределить нельзя — остальные всё равно дадут пустой ответ
      }
    };
    define('readyState', 4);
    define('status', 200);
    define('statusText', 'OK');
    define('responseURL', url);
    define('response', body);
    define('responseText', isJson ? '' : body);
    setTimeout(() => {
      xhr.dispatchEvent(new Event('readystatechange'));
      xhr.dispatchEvent(new Event('load'));
      xhr.dispatchEvent(new Event('loadend'));
    }, 0);
  }

  function patchXhr(win) {
    const Xhr = win.XMLHttpRequest;
    if (!Xhr || !Xhr.prototype) {
      return;
    }
    const proto = Xhr.prototype;
    const nativeOpen = proto.open;
    const nativeSend = proto.send;

    proto.open = function patchedOpen(method, url) {
      this.__rutubeNoAdsUrl = typeof url === 'string' ? url : '';
      return nativeOpen.apply(this, arguments);
    };

    proto.send = function patchedSend() {
      const url = this.__rutubeNoAdsUrl || '';
      if (blockingEnabled && isAdUrl(url)) {
        fakeXhrResponse(this, url);
        return undefined;
      }
      return nativeSend.apply(this, arguments);
    };
  }

  function ensureStyles() {
    if (styleElement && styleElement.isConnected) {
      return;
    }
    const style = document.createElement('style');
    style.textContent = AD_UI_CSS;
    const parent = document.head || document.documentElement;
    if (!parent) {
      return;
    }
    parent.appendChild(style);
    styleElement = style;
  }

  function removeStyles() {
    if (styleElement && styleElement.parentNode) {
      styleElement.parentNode.removeChild(styleElement);
    }
    styleElement = null;
  }

  function broadcastState() {
    try {
      window.postMessage({ source: MESSAGE_SOURCE, type: 'state', enabled: blockingEnabled }, '*');
    } catch (error) {
      // страница может запретить postMessage — состояние всё равно лежит в localStorage
    }
  }

  function mountToggle() {
    if (window.top !== window || toggleHost) {
      return;
    }
    const existing = document.getElementById(TOGGLE_HOST_ID);
    if (existing) {
      toggleHost = existing;
      return;
    }
    const parent = document.body || document.documentElement;
    if (!parent) {
      return;
    }
    const host = document.createElement('div');
    host.id = TOGGLE_HOST_ID;
    const shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = TOGGLE_CSS;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'toggle';
    const dot = document.createElement('span');
    dot.className = 'dot';
    const label = document.createElement('span');
    label.className = 'label';
    button.appendChild(dot);
    button.appendChild(label);
    button.addEventListener('click', () => setBlocking(!blockingEnabled));
    shadow.appendChild(style);
    shadow.appendChild(button);
    parent.appendChild(host);
    toggleHost = host;
    toggleParts = { button, label };
    updateToggle();
  }

  function updateToggle() {
    if (!toggleParts) {
      return;
    }
    const { button, label } = toggleParts;
    const text = formatToggleLabel(blockingEnabled);
    if (label.textContent !== text) {
      label.textContent = text;
    }
    button.setAttribute('aria-pressed', String(blockingEnabled));
    button.setAttribute(
      'title',
      blockingEnabled ? 'Нажмите, чтобы вернуть рекламу RUTUBE' : 'Нажмите, чтобы отключить рекламу RUTUBE'
    );
    button.classList.toggle('off', !blockingEnabled);
  }

  function applyBlockingState(enabled) {
    blockingEnabled = enabled;
    if (enabled) {
      ensureStyles();
    } else {
      removeStyles();
      release();
    }
    updateToggle();
  }

  function setBlocking(enabled) {
    applyBlockingState(enabled);
    persistState(enabled);
    broadcastState();
    tick();
  }

  function onPageMessage(event) {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (!data || data.source !== MESSAGE_SOURCE || data.type !== 'state') {
      return;
    }
    if (typeof data.enabled !== 'boolean' || data.enabled === blockingEnabled) {
      return;
    }
    applyBlockingState(data.enabled);
    persistState(data.enabled);
    tick();
  }

  function onReady() {
    mountToggle();
    watchAdblockNotice();
    broadcastState();
    setTimeout(broadcastState, 1500);
  }

  function start() {
    blockingEnabled = readStoredState();
    patchFetch(window);
    patchXhr(window);
    if (blockingEnabled) {
      ensureStyles();
    }
    window.addEventListener('message', onPageMessage);
    setInterval(tick, TICK_INTERVAL_MS);
    broadcastState();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', onReady, { once: true });
    } else {
      onReady();
    }
    tick();
  }

  globalThis.__rutubeNoAdsDebug = {
    version: VERSION,
    isAdUrl,
    isRutubeApiUrl,
    stripAdPayload,
    hasAdToken,
    normalizeEnabled,
    formatToggleLabel,
    matchesAdblockNotice
  };

  try {
    start();
  } catch (error) {
    globalThis.__rutubeNoAdsDebug.lastError = String(error);
  }
})();
